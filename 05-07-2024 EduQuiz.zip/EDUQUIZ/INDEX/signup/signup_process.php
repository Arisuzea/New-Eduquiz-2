<?php
include '../connect.php'; // Include your database connection file

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Extract form data
    $firstname = $_POST["firstname"];
    $lastname = $_POST["lastname"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $repeatpassword = $_POST["repeatpassword"];

    // Check if passwords match
    if ($password !== $repeatpassword) {
        echo "<script>alert('Error: Passwords do not match'); window.location.href='signup.php';</script>";
        exit;
    }

    // Check if email is already registered
    $checkEmailQuery = "SELECT id FROM users WHERE email = ?";
    $checkStmt = $mysqli->prepare($checkEmailQuery);
    $checkStmt->bind_param("s", $email);
    $checkStmt->execute();
    $checkStmt->store_result();

    if ($checkStmt->num_rows > 0) {
        echo "<script>alert('Error: Email is already registered'); window.location.href='signup.php';</script>";
        exit;
    }

    // Insert user data into the users table
    $insertUserQuery = "INSERT INTO users (firstname, lastname, email, password) VALUES (?, ?, ?, ?)";
    $insertStmt = $mysqli->prepare($insertUserQuery);
    $insertStmt->bind_param("ssss", $firstname, $lastname, $email, $password); // Not hashing the password

    if ($insertStmt->execute()) {
        // Get the ID of the newly inserted user
        $userId = $insertStmt->insert_id;

        // Create a user-specific table for quiz scores
        $userTable = "user_" . $userId . "_scores";
        $createTableQuery = "CREATE TABLE IF NOT EXISTS $userTable (
            quiz_id INT PRIMARY KEY AUTO_INCREMENT,
            quiz_name VARCHAR(255),
            score INT,
            date_completed DATETIME DEFAULT CURRENT_TIMESTAMP
        )";

        if ($mysqli->query($createTableQuery)) {
            // Redirect to login page
            header("Location: ../Login/login.php");
            exit;
        } else {
            echo "Error creating user-specific table: " . $mysqli->error;
        }
    } else {
        echo "Error inserting user data: " . $insertStmt->error;
    }

    $insertStmt->close();
    $checkStmt->close();
}

$mysqli->close();

<?php
session_start();
include '../connect.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reward Received</title>
</head>
<body>
    <h1>Reward Received</h1>
    <?php
    if (isset($_GET['points'])) {
        $points = $_GET['points'];
        echo "<p>Congratulations! You have received $points points as a reward.</p>";
    } else {
        echo "<p>Error: Points parameter not found in the URL.</p>";
    }
    ?>
</body>
</html>

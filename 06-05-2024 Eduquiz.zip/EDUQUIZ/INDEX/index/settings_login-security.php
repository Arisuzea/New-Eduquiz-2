<?php
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect the user to the home page
    header('Location: ../logout/home-page.php');
    exit(); // Stop further execution
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/login/settings_login-security.css">
    <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
    <title>Settings</title>
</head>
<body>
    <!-- HEADER -->
    <div class="header">
        <div class="topnav">
            <img onclick="Settings()" src="https://media.discordapp.net/attachments/1223234109283762271/1224680176718446733/PS.png?ex=66317d0b&is=66302b8b&hm=5c02f268e07542449f06a9c6a69c5e9a15bf27f8c1069694f50f178ee048f72a&=&format=webp&quality=lossless" alt="Expired">
            <a class="active" href="../login/home-page.php">Contact Us</a>
            <a href="../index/about.php">About</a>
            <a href="../index/quizzes.php">Quizzes</a>
            <a href="../index/home-page.php">Home</a>
        </div>
        <div class="logo">
            <a href="../login/home-page.php">
                <img src="https://media.discordapp.net/attachments/1223234109283762271/1223234253110771783/Official_Logo.png?ex=6631806c&is=66302eec&hm=6f60e5c6b75a4e3721f84e804f6fb3300e4d9d6129ca1891cb114f03936ce7da&=&format=webp&quality=lossless&width=1093&height=683" alt="Logo">
            </a>
            <h3>EduQuiz</h3>
        </div>
    </div>

    <!-- SETTINGS CONTENT -->
    <div class="hero">
        <div class="container_1">
            <h1>Settings</h1>
            <a href="../index/settings_personal-info.php" id="id_1">Personal Info</a>
            <a href="../index/settings_login-security.php" id="id_2">Login & Security</a>
            <span class="hr_1"> <hr></span>
            <span class="hr-faq">
                <hr>
            </span>
        </div>
    <!-- CHANGE EMAIL FORM -->
        <div class="container_2">
            <form action="update_security.php" method="POST">
                <input type="hidden" name="form-type" value="email">
                <div class="edit_email">
                    <label for="new-email">New Email Address:</label>
                    <input type="email" name="new-email" id="new-email" required>
                </div>
                <div class="btn-container">
                    <button type="submit" class="btn-change" id="id-change-email">Change Email</button>
                </div>
            </form>
        </div>

    <!-- CHANGE PASSWORD FORM -->
        <div class="container_2">
            <form action="update_security.php" method="POST">
                <input type="hidden" name="form-type" value="password"> 
                <div class="edit_password">
                    <label for="new-password">New Password:</label>
                    <input type="password" name="new-password" id="new-password" required>
                </div>
                <div class="btn-container">
                    <button type="submit" class="btn-change" id="id-change-password">Change Password</button>
                </div>
            </form>
            <div class="rmv">
                <div class="lgt"><a href="../logout/logout.php">Logout</a></div> 
                <!-- <div class="pda"><a href="delete_account.php">Permanent delete Account</a></div> -->
            </div>
        </div>
    </div>
</body>
</html>

<?php
session_start();
include '../connect.php'; // Include your database connection file

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect or display an error message
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Check if the user has received a reward in the last 24 hours
$checkRewardQuery = "SELECT points FROM users WHERE id = ? AND last_reward > DATE_SUB(NOW(), INTERVAL 24 HOUR)";
$checkStmt = $mysqli->prepare($checkRewardQuery);
$checkStmt->bind_param("i", $user_id);
$checkStmt->execute();
$checkStmt->store_result();

if ($checkStmt->num_rows > 0) {
    // User has already received a reward in the last 24 hours
    // Redirect or display a message indicating that the reward is not available yet
    header("Location: rewards_not_available.php");
    exit;
}

// Generate a random number of points (e.g., between 10 and 50)
$points = rand(10, 50);

// Get the current reward points of the user
$getPointsQuery = "SELECT points FROM users WHERE id = ?";
$getPointsStmt = $mysqli->prepare($getPointsQuery);
$getPointsStmt->bind_param("i", $user_id);
$getPointsStmt->execute();
$getPointsStmt->bind_result($current_points);
$getPointsStmt->fetch();
$getPointsStmt->close();

// Update users table with the new reward points
$new_points = $current_points + $points;
$updatePointsQuery = "UPDATE users SET points = ?, last_reward = NOW() WHERE id = ?";
$updateStmt = $mysqli->prepare($updatePointsQuery);
$updateStmt->bind_param("ii", $new_points, $user_id);
$updateStmt->execute();
$updateStmt->close();

// Redirect or display a message indicating that the reward has been received
header("Location: reward_received.php?points=$points");
exit;
?>

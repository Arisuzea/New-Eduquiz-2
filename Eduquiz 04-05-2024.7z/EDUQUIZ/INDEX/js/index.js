function Myfunction() {
  window.location = "../logout/home-page.php";
}
function MyfunctionLogin() {
  window.location = "../login/home-page.php";
}
function Quizzes() {
  alert("You Cannot access, Quizzes. Please Log in first");
  window.location = "../login/login.php";
}
function Settings() {
  window.location = "../index/settings_personal-info.php";
}

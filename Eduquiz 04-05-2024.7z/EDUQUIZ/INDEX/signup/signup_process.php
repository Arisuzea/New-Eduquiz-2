<?php
include '../connect.php';

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstname = $_POST["firstname"];
    $lastname = $_POST["lastname"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    $repeatpassword = $_POST["repeatpassword"];

    // Check if match
    if ($password !== $repeatpassword) {
        echo "<script>alert('Error: Passwords do not match'); window.location.href='signup.php';</script>";
        exit;
    }

    // Validate password
    if (!preg_match('/^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{8,}$/', $password)) {
        echo "<script>alert('Error: Password must be 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character.'); window.location.href='signup.php';</script>";
        exit;
    }

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Check if email is already registered
    $checkEmailQuery = "SELECT id FROM users WHERE email = ?";
    $checkStmt = $mysqli->prepare($checkEmailQuery);
    $checkStmt->bind_param("s", $email);
    $checkStmt->execute();
    $checkStmt->store_result();

    if ($checkStmt->num_rows > 0) {
        echo "<script>alert('Error: Email is already registered'); window.location.href='signup.php';</script>";
        exit;
    }

    // Insert user data into the database
    $sql = "INSERT INTO users (firstname, lastname, email, password) VALUES (?, ?, ?, ?)";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("ssss", $firstname, $lastname, $email, $hashedPassword);

    if ($stmt->execute()) {
        // Redirect to login page
        header("Location: ../Login/login.php");
        exit;
    } else {
        echo "Error: " . $stmt->error;
    }

    
    $stmt->close();
    $checkStmt->close();
}

$mysqli->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Question</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        h1 {
            color: #0047ab; /* Dark blue heading color */
        }

        form {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            font-weight: bold;
            color: #0047ab; /* Dark blue label color */
        }

        input[type="text"],
        input[type="submit"],
        textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        input[type="text"]:focus,
        textarea:focus {
            outline: none;
            border-color: #0058e1; /* Darker blue border when focused */
        }

        input[type="submit"] {
            background-color: #0047ab; /* Dark blue button background color */
            color: #fff; /* White button text color */
            cursor: pointer;
            transition: background-color 0.3s;
        }

        input[type="submit"]:hover {
            background-color: #0058e1; /* Darker blue hover color for button */
        }

        #responseMessage {
            margin-top: 10px;
            color: green; /* Green color for success message */
        }

        /* Button styles */
        .btn-container {
            display: flex;
            justify-content: flex-end;
            margin-bottom: 20px;
        }

        .btn-container button {
            background-color: #0047ab;
            color: #fff;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .btn-container button:hover {
            background-color: #0058e1;
        }
    </style>
</head>
<body>
    <div class="btn-container">
        <button onclick="window.location.href='existing questions.php'">View Existing Questions</button>
    </div>

    <h1>Add New Question</h1>
    <form id="addQuestionForm">
        <label for="table_select">Select Table:</label><br>
        <select id="table_select" name="table_select" required>
            <option value="" selected disabled>Select Table</option>
            <!-- Existing tables with the same structure will be dynamically added here -->
            <option value="create_table">Create New Table</option>
        </select><br><br>

        <label for="table_name">Table Name (if creating a new table):</label><br>
        <input type="text" id="table_name" name="table_name" style="display: none;"><br><br>

        <label for="question">Question:</label><br>
        <textarea id="question" name="question" rows="4" required></textarea><br><br>

        <label for="correct_answer">Correct Answer:</label><br>
        <input type="text" id="correct_answer" name="correct_answer" required><br><br>

        <label for="incorrect_answers">Incorrect Answers (comma-separated):</label><br>
        <input type="text" id="incorrect_answers" name="incorrect_answers" required><br><br>

        <label for="explanation">Explanation:</label><br>
        <textarea id="explanation" name="explanation" rows="4" required></textarea><br><br>

        <input type="submit" value="Add Question">
    </form>

    <div id="responseMessage"></div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const tableSelect = document.getElementById('table_select');
            const tableNameInput = document.getElementById('table_name');

            // Fetch existing tables with the same structure
            fetch('fetch_tables.php')
                .then(response => response.json())
                .then(data => {
                    data.forEach(table => {
                        const option = document.createElement('option');
                        option.value = table;
                        option.textContent = table;
                        tableSelect.appendChild(option);
                    });
                })
                .catch(error => console.error('Error fetching tables:', error));

            tableSelect.addEventListener('change', function () {
                if (tableSelect.value === 'create_table') {
                    tableNameInput.style.display = 'block';
                    tableNameInput.required = true;
                } else {
                    tableNameInput.style.display = 'none';
                    tableNameInput.required = false;
                }
            });

            document.getElementById('addQuestionForm').addEventListener('submit', function(event) {
                event.preventDefault();
                const form = new FormData(this);

                fetch('create_question.php', {
                    method: 'POST',
                    body: form
                })
                .then(response => response.text())
                .then(message => {
                    document.getElementById('responseMessage').textContent = message;
                    document.getElementById('addQuestionForm').reset();
                })
                .catch(error => console.error('Error:', error));
            });
        });
    </script>
</body>
</html>

<?php

// Start session
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect the user to the login page
    header('Location: ../logout/home-page.php');
    exit(); // Stop further execution
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "eqs"; // Replace 'your_database' with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve selected table name from the form
    $tableName = $_POST['table_name'];

    // Set the session variable for the active table
    $_SESSION['active_table'] = $tableName;

    // Redirect to the admin page or another appropriate page
    header('Location: admin_page.php');
    exit(); // Stop further execution
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
</head>
<body>
    <h1>Select Active Table</h1>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <label for="table_select">Select Active Table:</label>
        <select name="table_name" id="table_select">
            <option value="table_env_ps1">Table for Environment of Adobe Photoshop Part 1</option>
            <option value="table_env_ps2">Table for Environment of Adobe Photoshop Part 2</option>
            <!-- Add options for other tables if needed -->
        </select>
        <br>
        <input type="submit" value="Set Active Table">
    </form>
</body>
</html>

<?php
// Close connection
$conn->close();
?>

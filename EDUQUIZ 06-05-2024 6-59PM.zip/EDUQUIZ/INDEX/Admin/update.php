<?php
// Check if the form data is received
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_GET['id'])) {
    $id = $_GET['id'];

    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "eqs_users";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $database);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind the update statement
    $stmt = $conn->prepare("UPDATE users SET firstname=?, lastname=?, email=?, password=? WHERE id=?");
    $stmt->bind_param("ssssi", $firstname, $lastname, $email, $password, $id);

    // Get data from the form arrays
    $firstname = $_POST['firstname'][0]; // Accessing the first element of the array
    $lastname = $_POST['lastname'][0];
    $email = $_POST['email'][0];
    $password = $_POST['password'][0];

    // Execute the update statement
    if ($stmt->execute()) {
        $response = array("success" => true);
        echo json_encode($response);
    } else {
        $response = array("success" => false);
        echo json_encode($response);
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
} else {
    $response = array("success" => false, "message" => "Invalid request");
    echo json_encode($response);
}
?>
